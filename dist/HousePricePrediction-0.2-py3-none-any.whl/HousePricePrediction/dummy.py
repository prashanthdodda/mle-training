from HousePricePrediction import ingest_data, train
