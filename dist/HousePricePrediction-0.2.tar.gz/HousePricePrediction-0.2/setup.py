from setuptools import setup

setup(
    name="HousePricePrediction",
    version="0.2",
    description="Testing installation of Package",
    author="Prashanth Dodda",
    author_email="prashanth.dodda@tigeranalytics.com",
    packages=["HousePricePrediction"],
    package_dir={"HousePricePrediction": "src/HousePricePrediction"},
)

# import pathlib

# from setuptools import find_packages, setup

# here = pathlib.Path(__file__).parent.resolve()
# long_description = (here / "README.md").read_text(encoding="utf-8")
# setup(
#     name="HousePricePrediction",
#     version="0.1",
#     description="To predict house price based on provided input data",
#     long_description=long_description,
#     classifiers=[
#         "Development Status :: Production Ready",
#         "Intended Audience :: Customer",
#         "Topic :: House price prediction",
#     ],
# )
